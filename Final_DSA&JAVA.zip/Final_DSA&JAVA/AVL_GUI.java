package dsa_oops;

import java.awt.EventQueue;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import java.awt.*;

public class AVL_GUI {

	private JFrame frame;
	private JTextField cropField, nField, pField, kField, phField, rainField, tempField;
	private JTextArea outputArea;
	private List<FieldZone> data = new ArrayList<>();

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AVL_GUI window = new AVL_GUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public AVL_GUI() {
		initialize();
	}

	private void initialize() {
		frame = new JFrame();
		frame.setTitle("Precision Agriculture - Soil Nutrient Tracker");
		frame.setBounds(100, 100, 620, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel lblCrop = new JLabel("Crop:");
		lblCrop.setBounds(30, 20, 80, 20);
		frame.getContentPane().add(lblCrop);

		cropField = new JTextField();
		cropField.setBounds(120, 20, 120, 20);
		frame.getContentPane().add(cropField);

		JLabel lblN = new JLabel("Nitrogen (N):");
		lblN.setBounds(30, 50, 100, 20);
		frame.getContentPane().add(lblN);

		nField = new JTextField();
		nField.setBounds(120, 50, 120, 20);
		frame.getContentPane().add(nField);

		JLabel lblP = new JLabel("Phosphorus (P):");
		lblP.setBounds(30, 80, 100, 20);
		frame.getContentPane().add(lblP);

		pField = new JTextField();
		pField.setBounds(120, 80, 120, 20);
		frame.getContentPane().add(pField);

		JLabel lblK = new JLabel("Potassium (K):");
		lblK.setBounds(30, 110, 100, 20);
		frame.getContentPane().add(lblK);

		kField = new JTextField();
		kField.setBounds(120, 110, 120, 20);
		frame.getContentPane().add(kField);

		JLabel lblPh = new JLabel("pH:");
		lblPh.setBounds(30, 140, 100, 20);
		frame.getContentPane().add(lblPh);

		phField = new JTextField();
		phField.setBounds(120, 140, 120, 20);
		frame.getContentPane().add(phField);

		JLabel lblRainfall = new JLabel("Rainfall (mm):");
		lblRainfall.setBounds(30, 170, 100, 20);
		frame.getContentPane().add(lblRainfall);

		rainField = new JTextField();
		rainField.setBounds(120, 170, 120, 20);
		frame.getContentPane().add(rainField);

		JLabel lblTemp = new JLabel("Temperature (°C):");
		lblTemp.setBounds(30, 200, 120, 20);
		frame.getContentPane().add(lblTemp);

		tempField = new JTextField();
		tempField.setBounds(150, 200, 90, 20);
		frame.getContentPane().add(tempField);

		outputArea = new JTextArea();
		outputArea.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(outputArea);
		scrollPane.setBounds(270, 20, 320, 330);
		frame.getContentPane().add(scrollPane);

		JButton btnAdd = new JButton("Add Zone");
		btnAdd.setBounds(30, 240, 100, 25);
		frame.getContentPane().add(btnAdd);

		JButton btnReport = new JButton("Generate Report");
		btnReport.setBounds(140, 240, 150, 25);
		frame.getContentPane().add(btnReport);

		// Action Listener - Add Zone
		btnAdd.addActionListener(e -> {
			try {
				String crop = cropField.getText();
				double n = Double.parseDouble(nField.getText());
				double p = Double.parseDouble(pField.getText());
				double k = Double.parseDouble(kField.getText());
				double ph = Double.parseDouble(phField.getText());
				double rain = Double.parseDouble(rainField.getText());
				double temp = Double.parseDouble(tempField.getText());

				FieldZone zone = new FieldZone(crop, n, p, k, ph, rain, temp);
				data.add(zone);
				outputArea.append("Zone Added:\n" + zone.displayInfo());

				// Clear fields
				cropField.setText(""); nField.setText(""); pField.setText(""); kField.setText("");
				phField.setText(""); rainField.setText(""); tempField.setText("");

			} catch (NumberFormatException ex) {
				JOptionPane.showMessageDialog(frame, "Please enter valid numerical values!");
			}
		});

		// Action Listener - Generate Report
		btnReport.addActionListener(e -> {
			long highN = data.stream().filter(z -> z.nitrogen > 100).count();
			long optimalPH = data.stream().filter(z -> z.pH >= 6.0 && z.pH <= 7.5).count();

			outputArea.append("\n===== Soil Nutrient Report =====\n");
			outputArea.append("Total Zones: " + data.size() + "\n");
			outputArea.append("High Nitrogen Zones (>100): " + highN + "\n");
			outputArea.append("Optimal pH Zones (6.0–7.5): " + optimalPH + "\n");
			outputArea.append("Insights:\n- Reduce nitrogen in high-N zones.\n- Optimal pH zones are suitable for diverse crops.\n\n");
		});
	}
}

class FieldZone {
	String crop;
	double nitrogen, phosphorus, potassium, pH, rainfall, temperature;

	public FieldZone(String crop, double nitrogen, double phosphorus, double potassium, double pH, double rainfall, double temperature) {
		this.crop = crop;
		this.nitrogen = nitrogen;
		this.phosphorus = phosphorus;
		this.potassium = potassium;
		this.pH = pH;
		this.rainfall = rainfall;
		this.temperature = temperature;
	}

	public String displayInfo() {
		return "Crop: " + crop + " | N: " + nitrogen + " | P: " + phosphorus + " | K: " + potassium +
				" | pH: " + pH + " | Rainfall: " + rainfall + " | Temp: " + temperature + "\n";
	}
}
