package dsa_oops;

class FieldZone {
    String crop;
    double nitrogen, phosphorus, potassium, pH, rainfall, temperature;

    public FieldZone(String crop, double nitrogen, double phosphorus, double potassium, double pH, double rainfall, double temperature) {
        this.crop = crop;
        this.nitrogen = nitrogen;
        this.phosphorus = phosphorus;
        this.potassium = potassium;
        this.pH = pH;
        this.rainfall = rainfall;
        this.temperature = temperature;
    }

    public void displayInfo() {
        System.out.println("Crop: " + crop + " | N: " + nitrogen + " | P: " + phosphorus + " | K: " + potassium + " | pH: " + pH + " | Rainfall: " + rainfall + " | Temperature: " + temperature);
    }
}
