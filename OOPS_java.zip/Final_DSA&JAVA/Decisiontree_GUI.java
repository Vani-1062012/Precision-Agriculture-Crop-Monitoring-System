package dsa_oops;

import java.awt.EventQueue;
import javax.swing.*;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.*;

public class Decisiontree_GUI {

	private JFrame frame;
	private JTextField[] inputFields = new JTextField[6];
	private JTextArea outputArea;

	// Data Structures
	static List<double[]> features = new ArrayList<>();
	static List<Integer> labels = new ArrayList<>();
	static Map<Integer, String> labelToCrop = new HashMap<>();
	static Map<String, Integer> cropToLabel = new HashMap<>();
	static String[] featureNames = {"N", "P", "K", "pH", "rainfall", "temperature"};
	static Node decisionTree;

	// Node class for the Decision Tree
	static class Node {
		int feature;
		double threshold;
		Node left, right;
		Integer value;

		Node(Integer value) {
			this.value = value;
		}

		Node(int feature, double threshold, Node left, Node right) {
			this.feature = feature;
			this.threshold = threshold;
			this.left = left;
			this.right = right;
		}
	}

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				Decisiontree_GUI window = new Decisiontree_GUI();
				window.frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public Decisiontree_GUI() {
		initialize();
		try {
			readCSV("C:\\Users\\Shivananda\\Downloads\\traindataset.csv");
			decisionTree = buildTree(features, labels, 0, 5);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);

		JLabel titleLabel = new JLabel("Crop Recommendation");
		titleLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		titleLabel.setBounds(140, 10, 250, 30);
		frame.getContentPane().add(titleLabel);

		for (int i = 0; i < featureNames.length; i++) {
			JLabel label = new JLabel(featureNames[i] + ":");
			label.setBounds(50, 60 + i * 40, 100, 25);
			frame.getContentPane().add(label);

			inputFields[i] = new JTextField();
			inputFields[i].setBounds(160, 60 + i * 40, 200, 25);
			frame.getContentPane().add(inputFields[i]);
		}

		JButton predictButton = new JButton("Predict");
		predictButton.setBounds(180, 320, 100, 30);
		frame.getContentPane().add(predictButton);

		outputArea = new JTextArea();
		outputArea.setEditable(false);
		outputArea.setBounds(50, 370, 380, 60);
		frame.getContentPane().add(outputArea);

		predictButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double[] input = new double[6];
				try {
					for (int i = 0; i < 6; i++) {
						input[i] = Double.parseDouble(inputFields[i].getText());
					}
					int result = predict(input, decisionTree);
					outputArea.setText("Recommended Crop: " + labelToCrop.get(result));
				} catch (Exception ex) {
					outputArea.setText("Invalid input. Please enter valid numbers.");
				}
			}
		});
	}

	// --- Core Logic Below ---

	static void readCSV(String fileName) throws IOException {
		BufferedReader br = new BufferedReader(new FileReader(fileName));
		String line = br.readLine(); // Skip header

		Set<String> crops = new HashSet<>();
		while ((line = br.readLine()) != null) {
			String[] parts = line.split(",");
			crops.add(parts[1]);
		}
		br.close();

		int label = 0;
		for (String crop : crops) {
			cropToLabel.put(crop, label);
			labelToCrop.put(label, crop);
			label++;
		}

		br = new BufferedReader(new FileReader(fileName));
		br.readLine(); // Skip header again

		while ((line = br.readLine()) != null) {
			String[] parts = line.split(",");
			String crop = parts[1];
			double[] feature = new double[6];
			for (int i = 0; i < 6; i++) {
				feature[i] = Double.parseDouble(parts[i + 2]);
			}
			features.add(feature);
			labels.add(cropToLabel.get(crop));
		}
		br.close();
	}

	static double entropy(List<Integer> y) {
		Map<Integer, Integer> count = new HashMap<>();
		for (int val : y) count.put(val, count.getOrDefault(val, 0) + 1);
		double entropy = 0.0;
		int total = y.size();
		for (int freq : count.values()) {
			double p = (double) freq / total;
			entropy -= p * (Math.log(p) / Math.log(2));
		}
		return entropy;
	}

	static double infoGain(List<Integer> y, List<Integer> leftIndices, List<Integer> rightIndices) {
		double parentEntropy = entropy(y);
		int n = y.size();
		int nLeft = leftIndices.size();
		int nRight = rightIndices.size();
		if (nLeft == 0 || nRight == 0) return 0;

		List<Integer> leftLabels = new ArrayList<>();
		for (int idx : leftIndices) leftLabels.add(y.get(idx));

		List<Integer> rightLabels = new ArrayList<>();
		for (int idx : rightIndices) rightLabels.add(y.get(idx));

		double childEntropy = (nLeft / (double) n) * entropy(leftLabels) +
				(nRight / (double) n) * entropy(rightLabels);

		return parentEntropy - childEntropy;
	}

	static int[] bestSplit(List<double[]> X, List<Integer> y) {
		double bestGain = 0;
		int bestFeature = -1;
		double bestThreshold = 0;

		int nFeatures = X.get(0).length;

		for (int feature = 0; feature < nFeatures; feature++) {
			Set<Double> thresholds = new HashSet<>();
			for (double[] row : X) thresholds.add(row[feature]);

			for (double t : thresholds) {
				List<Integer> left = new ArrayList<>();
				List<Integer> right = new ArrayList<>();

				for (int i = 0; i < X.size(); i++) {
					if (X.get(i)[feature] <= t) left.add(i);
					else right.add(i);
				}

				double gain = infoGain(y, left, right);
				if (gain > bestGain) {
					bestGain = gain;
					bestFeature = feature;
					bestThreshold = t;
				}
			}
		}

		return new int[]{bestFeature, (int) bestThreshold};
	}

	static Node buildTree(List<double[]> X, List<Integer> y, int depth, int maxDepth) {
		if (new HashSet<>(y).size() == 1 || depth == maxDepth) {
			int mostCommon = mostCommonLabel(y);
			return new Node(mostCommon);
		}

		int[] split = bestSplit(X, y);
		int feature = split[0];
		double threshold = split[1];

		if (feature == -1) {
			int mostCommon = mostCommonLabel(y);
			return new Node(mostCommon);
		}

		List<double[]> leftX = new ArrayList<>();
		List<Integer> leftY = new ArrayList<>();
		List<double[]> rightX = new ArrayList<>();
		List<Integer> rightY = new ArrayList<>();

		for (int i = 0; i < X.size(); i++) {
			if (X.get(i)[feature] <= threshold) {
				leftX.add(X.get(i));
				leftY.add(y.get(i));
			} else {
				rightX.add(X.get(i));
				rightY.add(y.get(i));
			}
		}

		Node left = buildTree(leftX, leftY, depth + 1, maxDepth);
		Node right = buildTree(rightX, rightY, depth + 1, maxDepth);

		return new Node(feature, threshold, left, right);
	}

	static int predict(double[] x, Node node) {
		if (node.value != null) return node.value;
		if (x[node.feature] <= node.threshold) {
			return predict(x, node.left);
		} else {
			return predict(x, node.right);
		}
	}

	static int mostCommonLabel(List<Integer> y) {
		Map<Integer, Integer> count = new HashMap<>();
		for (int val : y) count.put(val, count.getOrDefault(val, 0) + 1);
		int maxCount = 0, label = -1;
		for (Map.Entry<Integer, Integer> entry : count.entrySet()) {
			if (entry.getValue() > maxCount) {
				maxCount = entry.getValue();
				label = entry.getKey();
			}
		}
		return label;
	}
}
