package dsa_oops;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Multiarray_GUI {

	private JFrame frame;
	private JTextArea outputArea;
	private JTextField filePathField, zoneField, paramField, valueField;
	private SoilNutrientTracker tracker;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				Multiarray_GUI window = new Multiarray_GUI();
				window.frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Multiarray_GUI() {
		tracker = new SoilNutrientTracker();
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Soil Nutrient Tracker");
		frame.setBounds(100, 100, 700, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout());

		// Top Panel
		JPanel topPanel = new JPanel();
		topPanel.setLayout(new FlowLayout());

		filePathField = new JTextField("C:\\\\Users\\\\Shivananda\\\\Downloads\\\\traindataset.csv", 30);
		topPanel.add(filePathField);

		JButton loadButton = new JButton("Load Data");
		loadButton.addActionListener(e -> {
			tracker.loadData(filePathField.getText());
			outputArea.setText("Data loaded successfully!\n");
		});
		topPanel.add(loadButton);

		JButton displayButton = new JButton("Display Data");
		displayButton.addActionListener(e -> {
			outputArea.setText("");
			for (FieldZone zone : tracker.data) {
				outputArea.append(zone.crop + " | N:" + zone.nitrogen +
						" | P:" + zone.phosphorus + " | K:" + zone.potassium +
						" | pH:" + zone.pH + " | Rainfall:" + zone.rainfall +
						" | Temp:" + zone.temperature + "\n");
			}
		});
		topPanel.add(displayButton);
		frame.getContentPane().add(topPanel, BorderLayout.NORTH);

		// Center Output Area
		outputArea = new JTextArea();
		outputArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
		JScrollPane scrollPane = new JScrollPane(outputArea);
		frame.getContentPane().add(scrollPane, BorderLayout.CENTER);

		// Bottom Panel
		JPanel bottomPanel = new JPanel(new FlowLayout());

		zoneField = new JTextField("Zone Index", 8);
		paramField = new JTextField("Parameter Index", 10);
		valueField = new JTextField("New Value", 8);

		JButton updateButton = new JButton("Update");
		updateButton.addActionListener(e -> {
			try {
				int zoneIndex = Integer.parseInt(zoneField.getText().trim());
				int paramIndex = Integer.parseInt(paramField.getText().trim());
				double newValue = Double.parseDouble(valueField.getText().trim());
				tracker.updateValue(zoneIndex, paramIndex, newValue);
				outputArea.append("Updated zone " + zoneIndex + ", parameter " + paramIndex + " to " + newValue + "\n");
			} catch (Exception ex) {
				outputArea.append("Error: Invalid input values.\n");
			}
		});

		JButton trendButton = new JButton("Trend Analysis");
		trendButton.addActionListener(e -> {
			tracker.trendAnalysis();
			outputArea.append("Trend analysis performed. Check console for details.\n");
		});

		JButton reportButton = new JButton("Generate Report");
		reportButton.addActionListener(e -> {
			tracker.generateReport();
			outputArea.append("Report generated. Check console for details.\n");
		});

		bottomPanel.add(zoneField);
		bottomPanel.add(paramField);
		bottomPanel.add(valueField);
		bottomPanel.add(updateButton);
		bottomPanel.add(trendButton);
		bottomPanel.add(reportButton);

		frame.getContentPane().add(bottomPanel, BorderLayout.SOUTH);
	}
}

